Tile size upscaling pack (RA2 v9 + tile 140)
Changed:
- TILE: 110 -> 140
- UNIT speed/range/vision scaled by 1.272727 to keep 'tiles per second' and 'tiles of range' similar
- Unit radius (r) NOT scaled, so units have more physical room per tile (less crowd jitter)
Apply:
- overwrite client/index.html and client/js/game.js, then Ctrl+F5.
- check: window.__RA2_PATCH_VERSION__ === "v9"
