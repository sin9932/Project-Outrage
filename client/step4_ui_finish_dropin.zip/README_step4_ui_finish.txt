Step4 UI Finish (drop-in)

Replace these files in your repo:
  - client/index.html
  - client/js/game.js
  - client/js/ou_ui.js

What changed (P0 UI 마무리):
  - game.js: toast / applyMouseMode / tickSidebarBuild / updateSidebarButtons are now wrappers → ou_ui.js (fallback keeps old logic)
  - price tooltip binding is now truly one-time (no per-frame rebind leak)
  - money HUD update delegated to ou_ui.js
  - powerbar tooltip listeners in game.js are disabled when OUUI exists (avoid duplicate binding)
  - ou_ui.js: added toast(), updateMoney(), applyMouseMode(), updateBuildModeUI(), bindPriceTipsOnce()

Cache-bust:
  - index.html bumps ou_ui.js to ?v=ui4 and game.js to ?v=g_ui4
