RA2 PATCH V6 (more fundamental):
- Destination formation no longer uses reserveTile() at command time (prevents mass fallback/clumping).
- Destination selection uses canEnterGoalTile() which ignores reservations (only terrain/building + basic occupancy).
- Movement: blocked next tile -> WAIT (queue) instead of compression dancing.
Apply:
overwrite client/index.html and client/js/game.js then Ctrl+F5.
Confirm: window.__RA2_PATCH_VERSION__ === "v6"
