RA2 PATCH V8 (stops infantry jitter fundamentally):
- Infantry uses stable tile hysteresis (prevents tile boundary flip).
- When blocked/reservation fails: infantry QUEUE (vx/vy=0) and settle into sub-slot, no compression dancing.
- Blocked/queued units treated as anchored, so separation repulsion won't shove them into vibration.
Apply:
  overwrite client/index.html and client/js/game.js, then Ctrl+F5.
Confirm:
  window.__RA2_PATCH_VERSION__ === "v8"
