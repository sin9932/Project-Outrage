RA2 PATCH V5 (fundamental-ish): queue-based movement instead of compression dancing.
Apply:
1) overwrite client/index.html and client/js/game.js
2) Ctrl+F5
3) Console: window.__RA2_PATCH_VERSION__ === "v5"
What changed:
- If next tile reservation fails: try bypass, else STOP+WAIT and occasional repath (no vibration).
- If final tile blocked: immediate stop for a brief window before retargeting.
