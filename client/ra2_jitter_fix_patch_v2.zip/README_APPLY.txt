Apply (Windows):
1) Unzip
2) Copy/overwrite:
   - client/index.html
   - client/js/game.js
3) In Chrome: F12 -> Console, confirm it prints:
   RA2 PATCH V2 LOADED
   (Also window.__RA2_PATCH_VERSION__ === "v2")
4) Hard refresh: Ctrl+F5
