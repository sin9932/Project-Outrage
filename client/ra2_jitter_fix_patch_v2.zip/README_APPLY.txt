RA2 PATCH V4: stuck->wait+repath. Overwrite client/index.html and client/js/game.js. Ctrl+F5. window.__RA2_PATCH_VERSION__==='v4'.
