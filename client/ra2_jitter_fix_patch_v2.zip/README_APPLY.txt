RA2 jitter fix v3 (queueing + sub-slot per waypoint for infantry)

Apply:
1) Unzip
2) Overwrite:
   - client/index.html
   - client/js/game.js
3) Load in Chrome, open Console:
   should print: RA2 PATCH V2 LOADED
   and window.__RA2_PATCH_VERSION__ === "v3"
Notes:
- Infantry now chooses a sub-slot for each waypoint tile.
- If the next tile is temporarily full, infantry waits briefly instead of oscillating.
