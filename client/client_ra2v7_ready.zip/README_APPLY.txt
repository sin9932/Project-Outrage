RA2 PATCH V7: infantry queue-to-subslot when blocked (prevents jitter). Overwrite index.html + js/game.js. Ctrl+F5. Check window.__RA2_PATCH_VERSION__==='v7'.
